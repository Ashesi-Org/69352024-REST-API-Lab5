VOTERS_FILE = 'voters'
ELECTIONS_FILE = 'elections'
RESULTS_FILE = 'results'

STUDENT_ID = 'student_id'
ELECTION_ID = 'election_id'
SERVICE_KEY_DIR = './db_controller/serviceAccountKey.json'